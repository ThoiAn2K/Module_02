package com.codegym.has_ocp;

public interface Shipping {

    long calculateShippingFee();
}
