package com.codegym.has_ocp;

public class BaeMinShippingMethod implements Shipping {
    @Override
    public long calculateShippingFee() {
        //calculate shipping fee for bae min method
        return 0;
    }
}
