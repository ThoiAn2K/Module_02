package com.codegym.none_ocp;

public class ShippingMethod {
    public static final String GRAB_FOOD = "GRAB_FOOD";
    public static final String NOW_FOOD = "NOW_FOOD";
    public static final String BAE_MIN = "BAE_MIN";

    public static final String SHOPPE_FOOD = "SHOPPE_FOOD";

    public static final String GOJEX_FOOD = "GOJEX_FOOD";
}
