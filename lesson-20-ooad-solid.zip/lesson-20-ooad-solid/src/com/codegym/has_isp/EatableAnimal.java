package com.codegym.has_isp;

public interface EatableAnimal extends Animal {

    void eat();
}
