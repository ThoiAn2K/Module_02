package com.codegym.has_isp;

public interface RunnableAnimal extends Animal {

    void run();
}
