package com.codegym.has_isp;

public interface FlyableAnimal extends Animal {

    void fly();
}
