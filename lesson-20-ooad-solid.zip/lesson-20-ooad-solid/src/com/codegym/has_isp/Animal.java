package com.codegym.has_isp;

public interface Animal {

    void eat();
}
