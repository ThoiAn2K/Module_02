package com.codegym.has_isp;

public class Snake implements Animal {
    @Override
    public void eat() {
        //Eating...
    }
}
