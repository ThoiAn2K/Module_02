package com.codegym.has_lsp;

public interface Animal {
}
