package com.codegym.has_lsp;

public interface FlyableAnimal extends Animal {

    void fly();
}
