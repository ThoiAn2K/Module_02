package com.codegym.has_lsp;

public class Bird implements FlyableAnimal {
    @Override
    public void fly() {
        //Flying...
    }
}
