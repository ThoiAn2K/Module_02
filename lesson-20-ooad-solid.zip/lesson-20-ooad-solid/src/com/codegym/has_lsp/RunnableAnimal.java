package com.codegym.has_lsp;

public interface RunnableAnimal {

    void run();
}
