package com.codegym.has_srp;

import com.codegym.entity.User;

import java.util.List;

public class UserRepository {

    public void saveUser(User user) {
        //code to save new user to database
    }

    public List<User> getUsers() {
        return null;
    }
}
