package com.codegym.has_srp;

import com.codegym.entity.Product;

import java.util.List;

public class ProductRepository {

    public List<Product> getProducts() {
        //code to get list of products from database
        return null;
    }
}
