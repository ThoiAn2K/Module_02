package com.codegym.entity;

public class User {
}
