package com.codegym.entity;

public class Product {
}
