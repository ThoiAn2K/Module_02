package com.codegym.none_isp;

public interface Animal {

    void eat();
    void run();
    void fly();
}
