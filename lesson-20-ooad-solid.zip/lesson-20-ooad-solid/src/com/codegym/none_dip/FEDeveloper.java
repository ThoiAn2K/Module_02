package com.codegym.none_dip;

public class FEDeveloper {

    public void codeReactJS() {
        System.out.println("Coding ReactJS...");
    }

    public void codeVueJS() {
        System.out.println("Coding VueJS...");
    }
}
