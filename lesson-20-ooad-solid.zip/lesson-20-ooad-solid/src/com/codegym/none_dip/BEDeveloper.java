package com.codegym.none_dip;

public class BEDeveloper {

    public void codeJava() {
        System.out.println("Coding Java...");
    }

    public void codeCSharp() {
        System.out.println("Coding CSharp...");
    }
}
