package com.codegym.none_lsp;

public interface Animal {

    void fly();
}
