package com.codegym.none_lsp;

public class Bird implements Animal {
    @Override
    public void fly() {
        System.out.println("Bay bằng cánh");
    }
}
