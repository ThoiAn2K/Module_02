package com.codegym.has_dip;

public interface Developer {

    void develop();
}
